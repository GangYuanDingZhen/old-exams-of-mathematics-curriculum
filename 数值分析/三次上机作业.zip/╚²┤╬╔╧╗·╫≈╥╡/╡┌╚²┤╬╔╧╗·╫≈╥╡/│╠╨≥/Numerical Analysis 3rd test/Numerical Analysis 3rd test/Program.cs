﻿using System;

namespace Numerical_Analysis_3rd_test
{
    class Program
    {
        static void Main(string[] args)
        {
            // Question 1
            double a1 = 0;
            double b1 = 48;
            int n = 10;
            Func<double, double> Func = x => Math.Sqrt(1 + Math.Pow(Math.Cos(x), 2));
            double[,] R = RombergIntegration(Func, a1, b1, n);
            Console.WriteLine();



            // Question 2
            double a2 = 0; // 端点a
            double b2 = 5; // 端点b
            int N1 = 25; // 整数N
            int N2 = 50;
            int N3 = 100;
            double alpha = 1; // 初值条件alpha
            static double f(double t, double y)
            {
                return -y + t + 1;
            }
            Func<double, double> F = t => Math.Exp(-t) + t;
            double y = F(5);
            Console.WriteLine("y(5)准确值为：{0}", y);
            Console.WriteLine();

            // h = 0.2的Euler法
            Console.WriteLine("h = 0.2的Euler法：");
            double[] result0_2 = Euler(a2, b2, N1, alpha, f);
            for (int i = 0; i <= N1; i++)
            {
                double t = a2 + i * (b2 - a2) / N1;
                Console.WriteLine("t = {0}, w = {1}", t, result0_2[i]);
            }
            Console.WriteLine();
            // h = 0.1的Euler法
            Console.WriteLine("h = 0.1的Euler法：");
            double[] result0_1 = Euler(a2, b2, N2, alpha, f);
            for (int i = 0; i <= N2; i++)
            {
                double t = a2 + i * (b2 - a2) / N2;
                Console.WriteLine("t = {0}, w = {1}", t, result0_1[i]);
            }
            Console.WriteLine();
            // h = 0.05的Euler法
            Console.WriteLine("h = 0.05的Euler法：");
            double[] result0_05 = Euler(a2, b2, N3, alpha, f);
            for (int i = 0; i <= N3; i++)
            {
                double t = a2 + i * (b2 - a2) / N3;
                Console.WriteLine("t = {0}, w = {1}", t, result0_05[i]);
            }
            Console.WriteLine();

            // h = 0.2的改进Euler法
            Console.WriteLine("h = 0.2的改进Euler法：");
            double[] y1 = ModifiedEuler(a2, b2, N1, alpha, f);
            for (int i = 0; i <= N1; i++)
            {
                double t = a2 + i * (b2 - a2) / N1;
                Console.WriteLine("t = {0}, w = {1}", t, y1[i]);
            }
            Console.WriteLine();
            // h = 0.1的改进Euler法
            Console.WriteLine("h = 0.1的改进Euler法：");
            double[] y2 = ModifiedEuler(a2, b2, N2, alpha, f);
            for (int i = 0; i <= N2; i++)
            {
                double t = a2 + i * (b2 - a2) / N2;
                Console.WriteLine("t = {0}, w = {1}", t, y2[i]);
            }
            Console.WriteLine();
            // h = 0.05的改进Euler法
            Console.WriteLine("h = 0.05的改进Euler法：");
            double[] y3 = ModifiedEuler(a2, b2, N3, alpha, f);
            for (int i = 0; i <= N3; i++)
            {
                double t = a2 + i * (b2 - a2) / N3;
                Console.WriteLine("t = {0}, w = {1}", t, y3[i]);
            }
            Console.WriteLine();

            // h = 0.2的Runge-Kutta法
            Console.WriteLine("h = 0.2的Runge-Kutta法：");
            double[] w1 = RungeKutta(a2, b2, N1, alpha, f); // 调用函数
            for (int i = 0; i <= N1; i++)
            {
                double t = a2 + i * (b2 - a2) / N1; // 计算t
                Console.WriteLine("t = {0}, w = {1}", t, w1[i]); // 输出t和对应的w值
            }
            Console.WriteLine();
            // h = 0.1的Runge-Kutta法
            Console.WriteLine("h = 0.1的Runge-Kutta法：");
            double[] w2 = RungeKutta(a2, b2, N2, alpha, f); // 调用函数
            for (int i = 0; i <= N2; i++)
            {
                double t = a2 + i * (b2 - a2) / N2; // 计算t
                Console.WriteLine("t = {0}, w = {1}", t, w2[i]); // 输出t和对应的w值
            }
            Console.WriteLine();
            // h = 0.05的Runge-Kutta法
            Console.WriteLine("h = 0.05的Runge-Kutta法：");
            double[] w3 = RungeKutta(a2, b2, N3, alpha, f); // 调用函数
            for (int i = 0; i <= N3; i++)
            {
                double t = a2 + i * (b2 - a2) / N3; // 计算t
                Console.WriteLine("t = {0}, w = {1}", t, w3[i]); // 输出t和对应的w值
            }
            Console.WriteLine();
        }

        // 定义Romberg算法函数
        static double[,] RombergIntegration(Func<double, double> f, double a, double b, int n)
        {
            double h = b - a;
            double[,] R = new double[2, n + 1];

            R[0, 0] = h * (f(a) + f(b)) / 2;

            Console.WriteLine("R_1:\n{0}", R[0, 0]);

            for (int i = 2; i <= n; i++)
            {
                double sum = 0;
                for (int k = 1; k <= Math.Pow(2, i - 2); k++)
                {
                    double x = a + (2 * k - 1) * h / 2;
                    sum += f(x);
                }

                R[1, 0] = 0.5 * (R[0, 0] + h * sum);

                for (int j = 2; j <= i; j++)
                {
                    R[1, j - 1] = R[1, j - 2] + (R[1, j - 2] - R[0, j - 2]) / (Math.Pow(4, j - 1) - 1);
                }

                Console.WriteLine("R_{0}:", i);
                for (int j = 0; j <= i - 1; j++)
                {
                    Console.Write("{0}\t", R[1, j]);
                }
                Console.WriteLine();

                h /= 2;

                for (int j = 0; j <= i - 1; j++)
                {
                    R[0, j] = R[1, j];
                }
            }

            return R;
        }

        // 定义Euler方法函数
        static double[] Euler(double a, double b, int N, double alpha, Func<double, double, double> f)
        {
            double h = (b - a) / N; // 步长h
            double t = a;
            double w = alpha;

            double[] result = new double[N + 1];
            result[0] = alpha;

            for (int i = 1; i <= N; i++)
            {
                w = w + h * f(t, w); // 更新w
                t = a + i * h; // 更新t
                result[i] = w;
            }

            return result;
        }

        // 定义改进Euler方法函数
        static double[] ModifiedEuler(double a, double b, int N, double alpha, Func<double, double, double> f)
        {
            double h = (b - a) / N; // 步长h
            double t = a;
            double w = alpha;

            double[] result = new double[N + 1];
            result[0] = alpha;

            for (int i = 1; i <= N; i++)
            {
                w = w + (h / 2) * (f(t, w) + f(t + h, w + h * f(t, w))); // 更新w
                t = a + i * h; // 更新t
                result[i] = w;
            }

            return result;
        }

        // 定义Runge-Kutta方法函数
        static double[] RungeKutta(double a, double b, int N, double alpha, Func<double, double, double> f)
        {
            double[] w = new double[N + 1]; // 初始化w数组
            double h = (b - a) / N;
            double t = a;
            w[0] = alpha; // 初值条件

            for (int i = 1; i <= N; i++)
            {
                double K1 = h * f(t, w[i - 1]);
                double K2 = h * f(t + h / 2, w[i - 1] + K1 / 2);
                double K3 = h * f(t + h / 2, w[i - 1] + K2 / 2);
                double K4 = h * f(t + h, w[i - 1] + K3);
                w[i] = w[i - 1] + (K1 + 2 * K2 + 2 * K3 + K4) / 6; // 计算w值
                t = a + i * h; // 更新t
            }

            return w;
        }
    }
}
