﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NumericalAnalysis
{
    public partial class Form1 : Form
    {
        string str1 = Environment.CurrentDirectory + @"\testout.txt";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!File.Exists(str1))
            {
                FileStream fs1 = new FileStream(str1, FileMode.Create, FileAccess.Write);//创建写入文件 
                StreamWriter sw = new StreamWriter(fs1);
                sw.Close();
                fs1.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();

            if (radioButton1.Checked & comboBox1.Text == "第一问")
            {
                double[,] matrix = new double[,] {
                                              { 1.19,   2.11,  -100,  1 },
                                              { 14.2, -0.122,  12.2, -1 },
                                              {    0,    100, -99.9,  1 },
                                              { 15.3,  0.110, -13.1, -1 }
                                             };
                double[] rightSide = new double[] { 1.12, 3.44, 2.15, 4.16 };

                double[] x1 = Gauss(matrix, rightSide);
                richTextBox1.Text += "6.2 Solution1:\n";
                for (int i = 0; i < x1.Length; i++)
                {
                    richTextBox1.Text += String.Format("x{0} = {1}\n", i + 1, x1[i]);
                }
            }

            if (radioButton1.Checked & comboBox1.Text == "第二问")
            {
                double[,] matrix = new double[,] {
                                              { 1.19,   2.11,  -100,  1 },
                                              { 14.2, -0.122,  12.2, -1 },
                                              {    0,    100, -99.9,  1 },
                                              { 15.3,  0.110, -13.1, -1 }
                                             };
                double[] rightSide = new double[] { 1.12, 3.44, 2.15, 4.16 };

                try
                {
                    double[] x2 = Solve(matrix, rightSide);

                    richTextBox1.Text += "6.2 Solution2:\n";
                    for (int i = 0; i < x2.Length; i++)
                    {
                        richTextBox1.Text += String.Format("x[{0}] = {1}\n", i, x2[i]);
                    }
                }
                catch (ArgumentException ex)
                {
                    richTextBox1.Text += String.Format("Error：{0}", ex.Message);
                }
            }

            if (radioButton1.Checked & comboBox1.Text == "第三问")
            {
                double[,] matrix = new double[,] {
                                              { 1.19,   2.11,  -100,  1 },
                                              { 14.2, -0.122,  12.2, -1 },
                                              {    0,    100, -99.9,  1 },
                                              { 15.3,  0.110, -13.1, -1 }
                                             };
                double[] rightSide = new double[] { 1.12, 3.44, 2.15, 4.16 };

                double[] x3 = GaussianElimination(matrix, rightSide);
                richTextBox1.Text += "6.2 Solution3:\n";
                for (int i = 0; i < x3.Length; i++)
                {
                    richTextBox1.Text += String.Format("x{0} = {1}\n", i + 1, x3[i]);
                }
            }

            if (radioButton2.Checked)
            {
                double[,] A = { { 2, -1, 0, 0, 0, 0, 0, 0, 0, 0 },
                            { -1, 2, -1, 0, 0, 0, 0, 0, 0, 0 },
                            { 0, -1, 2, -1, 0, 0, 0, 0, 0, 0 },
                            { 0, 0, -1, 2, -1, 0, 0, 0, 0, 0 },
                            { 0, 0, 0, -1, 2, -1, 0, 0, 0, 0 },
                            { 0, 0, 0, 0, -1, 2, -1, 0, 0, 0 },
                            { 0, 0, 0, 0, 0, -1, 2, -1, 0, 0 },
                            { 0, 0, 0, 0, 0, 0, -1, 2, -1, 0 },
                            { 0, 0, 0, 0, 0, 0, 0, -1, 2, -1 },
                            { 0, 0, 0, 0, 0, 0, 0, 0, -1, 2 } };
                double[] b = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

                (double[,] L, double[,] U, double[] x) = CroutDecomposition(A, b);
                richTextBox1.Text += "6.6 Solution:\n";
                for (int i = 0; i < x.Length; i++)
                {
                    richTextBox1.Text += String.Format("x{0} = {1}\n", i + 1, x[i]);
                }
            }

            if (radioButton3.Checked)
            {
                // 定义三对角线性方程组的系数矩阵 A 和右侧向量 b
                double[,] teraMethodA = new double[40, 40];
                double[] teraMethodb = new double[40];
                for (int i = 1; i <= 40; i++)
                {
                    for (int j = 1; j <= 40; j++)
                    {
                        if (i == j)
                            teraMethodA[i - 1, j - 1] = 2 * i;
                        else if (j == i + 1 & (1 <= i & i <= 39))
                            teraMethodA[i - 1, j - 1] = -1;
                        else if (j == i - 1 & (2 <= i & i <= 40))
                            teraMethodA[i - 1, j - 1] = -1;
                        else
                            teraMethodA[i - 1, j - 1] = 0;
                    }
                }
                for (int i = 1; i <= 40; i++)
                    teraMethodb[i - 1] = 1.5 * i - 6;
                // 定义迭代法的初始近似值 x0 和误差容限 eps
                double[] x0 = new double[40];
                double eps = 1e-5;
                // 迭代次数上限
                int maxIterations = 100;
                // 定义松弛因子
                double omega = 1.2;

                if (comboBox2.Text == "Jacobi")
                {
                    double[] Jacobix = Jacobi(teraMethodA, teraMethodb, x0, eps);
                    richTextBox1.Text += "Jacobi Solution:\n";
                    String line;
                    try
                    {
                        //Pass the file path and file name to the StreamReader constructor
                        StreamReader sr = new StreamReader(str1);
                        //Read the first line of text
                        line = sr.ReadLine();
                        //Continue to read until you reach end of file
                        while (line != null)
                        {
                            //write the lie to console window
                            richTextBox1.Text += line + "\n";
                            //Read the next line
                            line = sr.ReadLine();
                        }
                        //close the file
                        sr.Close();
                    }
                    finally
                    {
                        System.IO.File.WriteAllText(str1, string.Empty);
                    }

                    for (int i = 0; i < Jacobix.Length; i++)
                    {
                        richTextBox1.Text += String.Format("x[{0}] = {1}\n", i, Jacobix[i]);
                    }
                }

                if (comboBox2.Text == "GS")
                {
                    double[] result = GaussSeidel(teraMethodA, teraMethodb, x0, maxIterations, eps);
                    richTextBox1.Text += "GaussSeidel Solution:\n";
                    for (int i = 0; i < result.Length; i++)
                    {
                        richTextBox1.Text += String.Format("x[{0}] = {1}\n", i, result[i]);
                    }
                }

                if (comboBox2.Text == "SOR(ω=1.2)")
                {
                    double[] SORx = SOR(teraMethodA, teraMethodb, x0, omega, maxIterations, eps);
                    richTextBox1.Text += "SOR Solution:\n";
                    for (int i = 0; i < SORx.Length; i++)
                    {
                        richTextBox1.Text += String.Format("x[{0}] = {1}\n", i, SORx[i]);
                    }
                }
            }

            if (radioButton4.Checked)
            {
                Func<double, double> f = x => Math.Pow(Math.E, 3 * x) - 5;
                Func<double, double> Func = x => x - Math.Pow(Math.E, 3 * x) + 5;
                Func<double, double> DFunc = x => 1 - 3 * Math.Pow(Math.E, 3 * x);
                double p0 = 0.5726219;
                double p1 = -1.5;
                double TOL = 1e-6;
                int N0 = 100;

                if (comboBox3.Text == "不动点迭代法")
                {
                    // 正根
                    double q0 = FixedPointIteration(f, p0, TOL, N0);
                    if (double.IsNaN(q0))
                    {
                        richTextBox1.Text += "不动点法迭代失败！";
                    }
                    else
                    {
                        richTextBox1.Text += String.Format("不动点法迭代正根：p = {0}\n", q0);
                    }
                    // 负根
                    double q1 = FixedPointIteration(f, p1, TOL, N0);
                    if (double.IsNaN(q1))
                    {
                        richTextBox1.Text += "不动点法迭代失败！";
                    }
                    else
                    {
                        richTextBox1.Text += String.Format("不动点法迭代负根：p = {0}\n", q1);
                    }
                }

                if (comboBox3.Text == "牛顿法")
                {
                    double p;
                    // 正根
                    if (Newton(Func, DFunc, p0, TOL, N0, out p))
                    {
                        String line;
                        try
                        {
                            //Pass the file path and file name to the StreamReader constructor
                            StreamReader sr = new StreamReader(str1);
                            //Read the first line of text
                            line = sr.ReadLine();
                            //Continue to read until you reach end of file
                            while (line != null)
                            {
                                //write the lie to console window
                                richTextBox1.Text += line + "\n";
                                //Read the next line
                                line = sr.ReadLine();
                            }
                            //close the file
                            sr.Close();
                        }
                        finally
                        {
                            System.IO.File.WriteAllText(str1, string.Empty);
                        }
                        richTextBox1.Text += String.Format("Newton法迭代成功，正根为：{0}\n", p);
                    }
                    else
                    {
                        richTextBox1.Text += "Newton法迭代失败！";
                    }

                    // 负根
                    if (Newton(Func, DFunc, p1, TOL, N0, out p))
                    {
                        String line;
                        try
                        {
                            //Pass the file path and file name to the StreamReader constructor
                            StreamReader sr = new StreamReader(str1);
                            //Read the first line of text
                            line = sr.ReadLine();
                            //Continue to read until you reach end of file
                            while (line != null)
                            {
                                //write the lie to console window
                                richTextBox1.Text += line + "\n";
                                //Read the next line
                                line = sr.ReadLine();
                            }
                            //close the file
                            sr.Close();
                        }
                        finally
                        {
                            System.IO.File.WriteAllText(str1, string.Empty);
                        }
                        richTextBox1.Text += String.Format("Newton法迭代成功，负根为：{0}\n", p);
                    }
                    else
                    {
                        richTextBox1.Text += "Newton法迭代失败！";
                    }
                }
            }

            if (radioButton5.Checked)
            {
                Func<double, double> g = x => x - Math.Sin(x);
                Func<double, double> dg = x => 1 - Math.Cos(x);
                Func<double, double> ddg = x => Math.Sin(x);
                double x0 = 0.1;
                double TOL = 1e-6;
                int N0 = 100;
                double p;

                if (comboBox4.Text == "第一问")
                {
                    if (Newton(g, dg, x0, TOL, N0, out p))
                    {
                        String line;
                        try
                        {
                            //Pass the file path and file name to the StreamReader constructor
                            StreamReader sr = new StreamReader(str1);
                            //Read the first line of text
                            line = sr.ReadLine();
                            //Continue to read until you reach end of file
                            while (line != null)
                            {
                                //write the lie to console window
                                richTextBox1.Text += line + "\n";
                                //Read the next line
                                line = sr.ReadLine();
                            }
                            //close the file
                            sr.Close();
                        }
                        finally
                        {
                            System.IO.File.WriteAllText(str1, string.Empty);
                        }
                        richTextBox1.Text += String.Format("Newton法迭代成功，解为：{0}\n", p);
                    }
                    else
                    {
                        richTextBox1.Text += "Newton法迭代失败！";
                    }
                }

                if (comboBox4.Text == "第二问")
                {
                    if (ImprovedNewtonRaphson(g, dg, ddg, x0, TOL, N0, out p))
                    {
                        String line;
                        try
                        {
                            //Pass the file path and file name to the StreamReader constructor
                            StreamReader sr = new StreamReader(str1);
                            //Read the first line of text
                            line = sr.ReadLine();
                            //Continue to read until you reach end of file
                            while (line != null)
                            {
                                //write the lie to console window
                                richTextBox1.Text += line + "\n";
                                //Read the next line
                                line = sr.ReadLine();
                            }
                            //close the file
                            sr.Close();
                        }
                        finally
                        {
                            System.IO.File.WriteAllText(str1, string.Empty);
                        }
                        richTextBox1.Text += String.Format("Newton-Raphson方法迭代成功，解为：{0}\n", p);
                    }
                    else
                    {
                        richTextBox1.Text += "Newton-Raphson方法迭代失败！";
                    }
                }

                if (comboBox4.Text == "第三问")
                {
                    if (Steffensen(g, x0, TOL, N0, out p))
                    {
                        String line;
                        try
                        {
                            //Pass the file path and file name to the StreamReader constructor
                            StreamReader sr = new StreamReader(str1);
                            //Read the first line of text
                            line = sr.ReadLine();
                            //Continue to read until you reach end of file
                            while (line != null)
                            {
                                //write the lie to console window
                                richTextBox1.Text += line + "\n";
                                //Read the next line
                                line = sr.ReadLine();
                            }
                            //close the file
                            sr.Close();
                        }
                        finally
                        {
                            System.IO.File.WriteAllText(str1, string.Empty);
                        }
                        richTextBox1.Text += String.Format("Steffensen方法迭代成功，解为：{0}\n", p);
                    }
                    else
                    {
                        richTextBox1.Text += "Steffensen方法迭代失败！";
                    }
                }
            }

            if (radioButton6.Checked)
            {
                Func<double, double> h = x => 600 * Math.Pow(x, 4) - 550 * Math.Pow(x, 3) + 200 * Math.Pow(x, 2) - 20 * x - 1;
                Func<double, double> dh = x => 2400 * Math.Pow(x, 3) - 1650 * Math.Pow(x, 2) + 400 * x - 20;
                double a = 0.1, b = 1, z0 = 0.1, z1 = 0.2;
                double eps = 1e-4;
                int N0 = 100;
                double p;

                if (comboBox5.Text == "Bisection method")
                {
                    double z = Bisection(h, a, b, eps, N0);
                    if (z == double.NaN)
                    {
                        richTextBox1.Text += "Bisection法迭代失败！";
                    }
                    else
                    {
                        String line;
                        try
                        {
                            //Pass the file path and file name to the StreamReader constructor
                            StreamReader sr = new StreamReader(str1);
                            //Read the first line of text
                            line = sr.ReadLine();
                            //Continue to read until you reach end of file
                            while (line != null)
                            {
                                //write the lie to console window
                                richTextBox1.Text += line + "\n";
                                //Read the next line
                                line = sr.ReadLine();
                            }
                            //close the file
                            sr.Close();
                        }
                        finally
                        {
                            System.IO.File.WriteAllText(str1, string.Empty);
                        }
                        richTextBox1.Text += $"Bisection法迭代成功，解为：{z}\n";
                    }
                }

                if (comboBox5.Text == "Newton’s method")
                {
                    if (Newton(h, dh, z0, eps, N0, out p))
                    {
                        String line;
                        try
                        {
                            //Pass the file path and file name to the StreamReader constructor
                            StreamReader sr = new StreamReader(str1);
                            //Read the first line of text
                            line = sr.ReadLine();
                            //Continue to read until you reach end of file
                            while (line != null)
                            {
                                //write the lie to console window
                                richTextBox1.Text += line + "\n";
                                //Read the next line
                                line = sr.ReadLine();
                            }
                            //close the file
                            sr.Close();
                        }
                        finally
                        {
                            System.IO.File.WriteAllText(str1, string.Empty);
                        }
                        richTextBox1.Text += String.Format("Newton法迭代成功，解为：{0}\n", p);
                    }
                    else
                    {
                        richTextBox1.Text += "Newton法迭代失败！";
                    }
                }

                if (comboBox5.Text == "Secant method")
                {
                    if (Secant(h, z0, z1, eps, N0, out p))
                    {
                        String line;
                        try
                        {
                            //Pass the file path and file name to the StreamReader constructor
                            StreamReader sr = new StreamReader(str1);
                            //Read the first line of text
                            line = sr.ReadLine();
                            //Continue to read until you reach end of file
                            while (line != null)
                            {
                                //write the lie to console window
                                richTextBox1.Text += line + "\n";
                                //Read the next line
                                line = sr.ReadLine();
                            }
                            //close the file
                            sr.Close();
                        }
                        finally
                        {
                            System.IO.File.WriteAllText(str1, string.Empty);
                        }
                        richTextBox1.Text += String.Format("Secant法迭代成功，解为：{0}\n", p);
                    }
                    else
                    {
                        richTextBox1.Text += "Secant法迭代失败！";
                    }
                }
            }

            if (radioButton7.Checked)
            {
                double a1 = 0;
                double b1 = 48;
                int n = 10;
                Func<double, double> Func = x => Math.Sqrt(1 + Math.Pow(Math.Cos(x), 2));
                double[,] R = RombergIntegration(Func, a1, b1, n);

                String line;
                try
                {
                    //Pass the file path and file name to the StreamReader constructor
                    StreamReader sr = new StreamReader(str1);
                    //Read the first line of text
                    line = sr.ReadLine();
                    //Continue to read until you reach end of file
                    while (line != null)
                    {
                        //write the lie to console window
                        richTextBox1.Text += line + "\n";
                        //Read the next line
                        line = sr.ReadLine();
                    }
                    //close the file
                    sr.Close();
                }
                finally
                {
                    System.IO.File.WriteAllText(str1, string.Empty);
                }
            }

            if (radioButton8.Checked)
            {
                double a2 = 0; // 端点a
                double b2 = 5; // 端点b
                int N1 = 25; // 整数N
                int N2 = 50;
                int N3 = 100;
                double alpha = 1; // 初值条件alpha
                //static double f(double t, double y)
                //{
                //   return -y + t + 1;
                //}
                Func<double, double> F = t => Math.Exp(-t) + t;
                double y = F(5);

                if (comboBox6.Text == "Euler’s method")
                {
                    if (comboBox7.Text == "h = 0.2")
                    {
                        richTextBox1.Text += "h = 0.2的Euler法：\n";
                        double[] result0_2 = Euler(a2, b2, N1, alpha, f);
                        for (int i = 0; i <= N1; i++)
                        {
                            double t = a2 + i * (b2 - a2) / N1;
                            richTextBox1.Text += String.Format("t = {0}, w = {1}\n", t, result0_2[i]);
                            if (t == 5)
                            {
                                double error = y - result0_2[i];
                                double er = (Math.Abs(error) / Math.Abs(y)) * 100;
                                richTextBox1.Text += String.Format("\n绝对误差 e = {0}\n", error);
                                richTextBox1.Text += String.Format("相对误差 er = {0} %\n", er);
                            }
                        }
                    }

                    if (comboBox7.Text == "h = 0.1")
                    {
                        richTextBox1.Text += "h = 0.1的Euler法：\n";
                        double[] result0_1 = Euler(a2, b2, N2, alpha, f);
                        for (int i = 0; i <= N2; i++)
                        {
                            double t = a2 + i * (b2 - a2) / N2;
                            richTextBox1.Text += String.Format("t = {0}, w = {1}\n", t, result0_1[i]);
                            if (t == 5)
                            {
                                double error = y - result0_1[i];
                                double er = (Math.Abs(error) / Math.Abs(y)) * 100;
                                richTextBox1.Text += String.Format("\n绝对误差 e = {0}\n", error);
                                richTextBox1.Text += String.Format("相对误差 er = {0} %\n", er);
                            }
                        }
                    }

                    if (comboBox7.Text == "h = 0.05")
                    {
                        richTextBox1.Text += "h = 0.05的Euler法：\n";
                        double[] result0_05 = Euler(a2, b2, N3, alpha, f);
                        for (int i = 0; i <= N3; i++)
                        {
                            double t = a2 + i * (b2 - a2) / N3;
                            richTextBox1.Text += String.Format("t = {0}, w = {1}\n", t, result0_05[i]);
                            if (t == 5)
                            {
                                double error = y - result0_05[i];
                                double er = (Math.Abs(error) / Math.Abs(y)) * 100;
                                richTextBox1.Text += String.Format("\n绝对误差 e = {0}\n", error);
                                richTextBox1.Text += String.Format("相对误差 er = {0} %\n", er);
                            }
                        }
                    }
                }

                if (comboBox6.Text == "Modified Euler’s method")
                {
                    if (comboBox7.Text == "h = 0.2")
                    {
                        richTextBox1.Text += "h = 0.2的改进Euler法：\n";
                        double[] y1 = ModifiedEuler(a2, b2, N1, alpha, f);
                        for (int i = 0; i <= N1; i++)
                        {
                            double t = a2 + i * (b2 - a2) / N1;
                            richTextBox1.Text += String.Format("t = {0}, w = {1}\n", t, y1[i]);
                            if (t == 5)
                            {
                                double error = y - y1[i];
                                double er = (Math.Abs(error) / Math.Abs(y)) * 100;
                                richTextBox1.Text += String.Format("\n绝对误差 e = {0}\n", error);
                                richTextBox1.Text += String.Format("相对误差 er = {0} %\n", er);
                            }
                        }
                    }

                    if (comboBox7.Text == "h = 0.1")
                    {
                        richTextBox1.Text += "h = 0.1的改进Euler法：\n";
                        double[] y2 = ModifiedEuler(a2, b2, N2, alpha, f);
                        for (int i = 0; i <= N2; i++)
                        {
                            double t = a2 + i * (b2 - a2) / N2;
                            richTextBox1.Text += String.Format("t = {0}, w = {1}\n", t, y2[i]);
                            if (t == 5)
                            {
                                double error = y - y2[i];
                                double er = (Math.Abs(error) / Math.Abs(y)) * 100;
                                richTextBox1.Text += String.Format("\n绝对误差 e = {0}\n", error);
                                richTextBox1.Text += String.Format("相对误差 er = {0} %\n", er);
                            }
                        }
                    }

                    if (comboBox7.Text == "h = 0.05")
                    {
                        richTextBox1.Text += "h = 0.05的改进Euler法：\n";
                        double[] y3 = ModifiedEuler(a2, b2, N3, alpha, f);
                        for (int i = 0; i <= N3; i++)
                        {
                            double t = a2 + i * (b2 - a2) / N3;
                            richTextBox1.Text += String.Format("t = {0}, w = {1}\n", t, y3[i]);
                            if (t == 5)
                            {
                                double error = y - y3[i];
                                double er = (Math.Abs(error) / Math.Abs(y)) * 100;
                                richTextBox1.Text += String.Format("\n绝对误差 e = {0}\n", error);
                                richTextBox1.Text += String.Format("相对误差 er = {0} %\n", er);
                            }
                        }
                    }
                }

                if (comboBox6.Text == "Runge-Kutta Method order four")
                {
                    if (comboBox7.Text == "h = 0.2")
                    {
                        richTextBox1.Text += "h = 0.2的Runge-Kutta法：\n";
                        double[] w1 = RungeKutta(a2, b2, N1, alpha, f); // 调用函数
                        for (int i = 0; i <= N1; i++)
                        {
                            double t = a2 + i * (b2 - a2) / N1; // 计算t
                            richTextBox1.Text += String.Format("t = {0}, w = {1}\n", t, w1[i]); // 输出t和对应的w值
                            if (t == 5)
                            {
                                double error = y - w1[i];
                                double er = (Math.Abs(error) / Math.Abs(y)) * 100;
                                richTextBox1.Text += String.Format("\n绝对误差 e = {0}\n", error);
                                richTextBox1.Text += String.Format("相对误差 er = {0} %\n", er);
                            }
                        }
                    }

                    if (comboBox7.Text == "h = 0.1")
                    {
                        richTextBox1.Text += "h = 0.1的Runge-Kutta法：\n";
                        double[] w2 = RungeKutta(a2, b2, N2, alpha, f); // 调用函数
                        for (int i = 0; i <= N2; i++)
                        {
                            double t = a2 + i * (b2 - a2) / N2; // 计算t
                            richTextBox1.Text += String.Format("t = {0}, w = {1}\n", t, w2[i]); // 输出t和对应的w值
                            if (t == 5)
                            {
                                double error = y - w2[i];
                                double er = (Math.Abs(error) / Math.Abs(y)) * 100;
                                richTextBox1.Text += String.Format("\n绝对误差 e = {0}\n", error);
                                richTextBox1.Text += String.Format("相对误差 er = {0} %\n", er);
                            }
                        }
                    }

                    if (comboBox7.Text == "h = 0.05")
                    {
                        richTextBox1.Text += "h = 0.05的Runge-Kutta法：\n";
                        double[] w3 = RungeKutta(a2, b2, N3, alpha, f); // 调用函数
                        for (int i = 0; i <= N3; i++)
                        {
                            double t = a2 + i * (b2 - a2) / N3; // 计算t
                            richTextBox1.Text += String.Format("t = {0}, w = {1}\n", t, w3[i]); // 输出t和对应的w值
                            if (t == 5)
                            {
                                double error = y - w3[i];
                                double er = (Math.Abs(error) / Math.Abs(y)) * 100;
                                richTextBox1.Text += String.Format("\n绝对误差 e = {0}\n", error);
                                richTextBox1.Text += String.Format("相对误差 er = {0} %\n", er);
                            }
                        }
                    }
                }
            }
        }

        /// 3*) Gaussian elimination with scaled partial pivoting.
        public static double[] GaussianElimination(double[,] A, double[] b)
        {
            int n = b.Length;

            // 初始化比例因子
            double[] s = new double[n];
            for (int i = 0; i < n; i++)
            {
                s[i] = Math.Abs(A[i, 0]);
                for (int j = 1; j < n; j++)
                {
                    if (Math.Abs(A[i, j]) > s[i])
                    {
                        s[i] = Math.Abs(A[i, j]);
                    }
                }
            }

            // 比例因子部分选主元
            for (int k = 0; k < n - 1; k++)
            {
                double maxRatio = 0;
                int maxIndex = k;
                for (int i = k; i < n; i++)
                {
                    double ratio = Math.Abs(A[i, k] / s[i]);
                    if (ratio > maxRatio)
                    {
                        maxRatio = ratio;
                        maxIndex = i;
                    }
                }
                if (maxRatio == 0)
                {
                    throw new Exception("Singular matrix");
                }
                if (maxIndex != k)
                {
                    // 交换行
                    for (int j = k; j < n; j++)
                    {
                        double temp = A[k, j];
                        A[k, j] = A[maxIndex, j];
                        A[maxIndex, j] = temp;
                    }
                    double temp2 = b[k];
                    b[k] = b[maxIndex];
                    b[maxIndex] = temp2;
                    double temp3 = s[k];
                    s[k] = s[maxIndex];
                    s[maxIndex] = temp3;
                }

                // 消元
                for (int i = k + 1; i < n; i++)
                {
                    double factor = A[i, k] / A[k, k];
                    b[i] -= factor * b[k];
                    for (int j = k; j < n; j++)
                    {
                        A[i, j] -= factor * A[k, j];
                    }
                }
            }

            // 回代
            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0;
                for (int j = i + 1; j < n; j++)
                {
                    sum += A[i, j] * x[j];
                }
                x[i] = (b[i] - sum) / A[i, i];
            }
            return x;
        }

        /// 2) Gaussian elimination with partial pivoting.
        public static double[] Solve(double[,] A, double[] b)
        {
            int n = A.GetLength(0);

            for (int k = 0; k < n; k++) // k表示当前列
            {
                int pivotRow = k; // pivotRow表示绝对值最大的元素所在的行

                // 找到绝对值最大的元素所在的行
                for (int i = k + 1; i < n; i++)
                {
                    if (Math.Abs(A[i, k]) > Math.Abs(A[pivotRow, k]))
                    {
                        pivotRow = i;
                    }
                }

                // 将绝对值最大的元素所在的行与当前行进行交换（部分选主元）
                if (pivotRow != k)
                {
                    for (int j = k; j < n; j++)
                    {
                        double temp = A[k, j];
                        A[k, j] = A[pivotRow, j];
                        A[pivotRow, j] = temp;
                    }

                    double tempB = b[k];
                    b[k] = b[pivotRow];
                    b[pivotRow] = tempB;
                }

                // 检查矩阵是否奇异
                if (A[k, k] == 0)
                {
                    throw new ArgumentException("Matrix is singular.");
                }

                // 进行消元
                for (int i = k + 1; i < n; i++)
                {
                    double factor = A[i, k] / A[k, k];
                    for (int j = k + 1; j < n; j++)
                    {
                        A[i, j] -= factor * A[k, j];
                    }
                    b[i] -= factor * b[k];
                    A[i, k] = 0; // 将主元下方的元素置为0
                }
            }

            // 回代求解
            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0;
                for (int j = i + 1; j < n; j++)
                {
                    sum += A[i, j] * x[j];
                }
                x[i] = (b[i] - sum) / A[i, i];
            }

            return x;
        }

        /// 1) Gaussian elimination.
        public static double[] Gauss(double[,] A, double[] b)
        {
            int n = b.Length;

            // 前向消元
            for (int k = 0; k < n - 1; k++)
            {
                // 消元
                for (int i = k + 1; i < n; i++)
                {
                    double factor = A[i, k] / A[k, k];
                    for (int j = k + 1; j < n; j++)
                    {
                        A[i, j] -= factor * A[k, j];
                    }
                    b[i] -= factor * b[k];
                }
            }

            // 回带求解
            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0.0;
                for (int j = i + 1; j < n; j++)
                {
                    sum += A[i, j] * x[j];
                }
                x[i] = (b[i] - sum) / A[i, i];
            }

            return x;
        }

        // Doolittle factorization
        public static (double[,] L, double[,] U, double[] x) CroutDecomposition(double[,] matrix, double[] b)
        {
            int n = b.Length;
            double[,] L = new double[n, n];
            double[,] U = new double[n, n];
            double[] x = new double[n];

            // 执行 Crout 分解
            L[0, 0] = matrix[0, 0];
            U[0, 0] = 1.0;
            for (int i = 1; i < n; i++)
            {
                L[i, i - 1] = matrix[i, i - 1] / U[i - 1, i - 1];
                U[i - 1, i] = matrix[i - 1, i] / L[i - 1, i - 1];
                L[i, i] = matrix[i, i] - L[i, i - 1] * U[i - 1, i];
                U[i, i] = 1.0;
            }

            // 使用正向替换求解 Ly = b
            double[] y = new double[n];
            y[0] = b[0] / L[0, 0];
            for (int i = 1; i < n; i++)
            {
                double sum = 0.0;
                for (int j = 0; j < i; j++)
                {
                    sum += L[i, j] * y[j];
                }
                y[i] = (b[i] - sum) / L[i, i];
            }

            // 使用反向替换求解 Ux = y
            x[n - 1] = y[n - 1];
            for (int i = n - 2; i >= 0; i--)
            {
                double sum = 0.0;
                for (int j = i + 1; j < n; j++)
                {
                    sum += U[i, j] * x[j];
                }
                x[i] = y[i] - sum;
            }

            return (L, U, x);
        }

        // Jacobi
        static double[] Jacobi(double[,] A, double[] b, double[] x0, double eps)
        {
            //AllocConsole();
            StreamWriter sw = new StreamWriter(Environment.CurrentDirectory + @"\testout.txt");

            int n = b.Length;
            double[] x = new double[n];     // 存放每次迭代后的解向量
            double[] x_new = new double[n]; // 存放每次迭代计算出的新解向量
            double err = 1;                 // 存放每次迭代后的误差

            // Jacobi 迭代法的迭代过程
            int k = 0;
            while (err > eps)
            {
                // 根据 Jacobi 迭代公式计算新的解向量
                for (int i = 0; i < n; i++)
                {
                    double sum = 0;
                    for (int j = 0; j < n; j++)
                    {
                        if (j != i)
                        {
                            sum += A[i, j] * x0[j];
                        }
                    }
                    x_new[i] = (b[i] - sum) / A[i, i];
                }

                // 计算新解向量与旧解向量之间的误差
                err = 0;
                for (int i = 0; i < n; i++)
                {
                    err += Math.Abs(x_new[i] - x0[i]);
                }

                // 将新解向量复制到解向量中，准备下一次迭代
                for (int i = 0; i < n; i++)
                {
                    x0[i] = x_new[i];
                }

                // 计算迭代次数
                k++;
            }

            sw.WriteLine("Number of iterations: {0}", k);

            sw.Close();

            return x_new;
        }

        // GaussSeidel
        static double[] GaussSeidel(double[,] A, double[] b, double[] x, int maxIterations, double tolerance)
        {
            int n = x.Length;
            int iterationCount = 0;
            double[] prevX = new double[n];

            while (iterationCount < maxIterations)
            {
                iterationCount++;

                // 保存上一次迭代的解向量
                for (int i = 0; i < n; i++)
                {
                    prevX[i] = x[i];
                }

                // 进行一次迭代
                for (int i = 0; i < n; i++)
                {
                    double sum = 0;

                    for (int j = 0; j < n; j++)
                    {
                        if (i != j)
                        {
                            sum += A[i, j] * x[j];
                        }
                    }

                    x[i] = (b[i] - sum) / A[i, i];
                }

                // 检查误差是否小于容限
                double error = 0;

                for (int i = 0; i < n; i++)
                {
                    error += Math.Abs(x[i] - prevX[i]);
                }

                if (error < tolerance)
                {
                    break;
                }
            }

            return x;
        }

        // SOR方法求解线性方程组 Ax = b
        // A: 系数矩阵，b: 常数矩阵，x0: 初始解向量，omega: 松弛因子，N: 迭代次数，TOL: 精度要求
        static double[] SOR(double[,] A, double[] b, double[] x0, double omega, int N, double TOL)
        {
            int n = b.Length; // 矩阵的大小

            // 定义迭代变量和误差数组
            int k = 0;
            double[] e = new double[n];

            // 定义解向量和中间变量数组
            double[] x = new double[n];
            double[] y = new double[n];

            // 初始化解向量
            for (int i = 0; i < n; i++)
            {
                x[i] = x0[i];
            }

            // 迭代求解
            while (k < N)
            {
                // 更新解向量
                for (int i = 0; i < n; i++)
                {
                    y[i] = x[i]; // 记录上一次的解向量
                    x[i] = (1 - omega) * x[i]; // 先乘以 (1 - omega)
                    double sum1 = 0;
                    double sum2 = 0;

                    // 求解 Ax = b 中的 sum1 和 sum2
                    for (int j = 0; j < i; j++)
                    {
                        sum1 += A[i, j] * x[j];
                    }
                    for (int j = i + 1; j < n; j++)
                    {
                        sum2 += A[i, j] * y[j];
                    }

                    // 更新解向量中第 i 个分量的值
                    x[i] = (1 - omega) * y[i] + omega * (b[i] - sum1 - sum2) / A[i, i];
                }

                // 计算当前解向量与上一次解向量的差的范数
                e[k] = Norm(x, y);

                // 如果误差小于精度要求，则跳出循环
                if (e[k] < TOL)
                {
                    break;
                }

                k++;
            }

            return x;
        }

        // 计算向量的范数
        // x: 向量，y: 向量
        static double Norm(double[] x, double[] y)
        {
            int n = x.Length; // 向量的大小
            double sum = 0;

            // 计算向量的平方差之和
            for (int i = 0; i < n; i++)
            {
                sum += Math.Pow(x[i] - y[i], 2);
            }

            // 返回向量的平方差之和的平方根
            return Math.Sqrt(sum);
        }

        // Bisection法
        static double Bisection(Func<double, double> func, double a, double b, double TOL, int N0)
        {
            StreamWriter sw = new StreamWriter(Environment.CurrentDirectory + @"\testout.txt");
            double p, f_a, f_b, f_p;
            int i;

            // 判断是否符合二分法的条件
            f_a = func(a);
            f_b = func(b);
            if (f_a * f_b >= 0)
            {
                sw.WriteLine("无法使用二分法求解！");
                return double.NaN;
            }

            // 开始二分法迭代
            for (i = 1; i <= N0; i++)
            {
                p = (a + b) / 2;
                f_p = func(p);
                if (Math.Abs(f_p) < TOL)
                {
                    sw.WriteLine($"迭代{i}次后，近似解为：{p}");
                    sw.Close();
                    return p;
                }
                else if (f_a * f_p < 0)
                {
                    b = p;
                    f_b = f_p;
                }
                else
                {
                    a = p;
                    f_a = f_p;
                }
            }

            sw.Close();
            return double.NaN;
        }

        // 不动点迭代函数
        static double FixedPointIteration(Func<double, double> f, double p0, double TOL, int N0)
        {
            double p = p0;
            for (int i = 0; i < N0; i++)
            {
                double pPrev = p;
                p = f(p);
                if (Math.Abs(p - pPrev) < TOL)
                {
                    return p;
                }
            }
            return double.NaN;
        }

        // Newton迭代法函数
        static bool Newton(Func<double, double> f, Func<double, double> df, double p0, double TOL, int N0, out double p)
        {

            StreamWriter sw = new StreamWriter(Environment.CurrentDirectory + @"\testout.txt");

            int i = 1;
            double fp0, dfp0;

            while (i <= N0)
            {
                fp0 = f(p0);     // 求函数值
                dfp0 = df(p0);   // 求导数值

                // 判断迭代是否出现NaN
                if (double.IsNaN(fp0 / dfp0))
                {
                    if (i == 1)
                    {
                        sw.WriteLine("第一次迭代就出现NaN，无法继续迭代！");
                        p = p0;
                        sw.Close();
                        return false;
                    }
                    else
                    {
                        sw.WriteLine("第{0}次迭代出现NaN，返回上一次迭代结果：{1}", i, p0);
                        p = p0;
                        sw.Close();
                        return true;
                    }
                }

                p = p0 - fp0 / dfp0; // 迭代公式
                sw.WriteLine("第{0}次迭代的解为：{1}", i, p);

                // 判断迭代是否收敛
                if (Math.Abs(p - p0) < TOL)
                {
                    sw.WriteLine("|p - p0| < TOL，迭代成功，解为：{0}", p);
                    sw.Close();
                    return true; // 迭代成功，返回true
                }

                p0 = p; // 更新近似解
                i++;
            }

            p = 0;

            sw.Close();
            return false; // 迭代失败，返回false
        }

        // 改进的Newton-Raphson方法
        static bool ImprovedNewtonRaphson(Func<double, double> f, Func<double, double> df, Func<double, double> ddf, double p0, double TOL, int N0, out double p)
        {

            StreamWriter sw = new StreamWriter(Environment.CurrentDirectory + @"\testout.txt");

            int i = 1;
            double fp0, dfp0, ddfp0;

            while (i <= N0)
            {
                fp0 = f(p0);     // 求函数值
                dfp0 = df(p0);   // 求导数值
                ddfp0 = ddf(p0); // 求二阶导数值

                // 判断迭代是否出现NaN
                if (double.IsNaN(fp0 * dfp0 / (Math.Pow(dfp0, 2) - fp0 * ddfp0)))
                {
                    if (i == 1)
                    {
                        sw.WriteLine("第一次迭代就出现NaN，无法继续迭代！");
                        p = p0;
                        sw.Close();
                        return false;
                    }
                    else
                    {
                        sw.WriteLine("第{0}次迭代出现NaN，返回上一次迭代结果：{1}", i, p0);
                        p = p0;
                        sw.Close();
                        return true;
                    }
                }

                // 迭代公式
                p = p0 - fp0 * dfp0 / (Math.Pow(dfp0, 2) - fp0 * ddfp0);
                sw.WriteLine("第{0}次迭代的解为：{1}", i, p);

                // 判断迭代是否收敛
                if (Math.Abs(p - p0) < TOL)
                {
                    sw.WriteLine("|p - p0| < TOL，迭代成功，解为：{0}", p);
                    sw.Close();
                    return true; // 迭代成功，返回true
                }

                p0 = p; // 更新近似解
                i++;
            }

            p = 0;
            sw.Close();
            return false; // 迭代失败，返回false
        }

        // Steffensen方法
        static bool Steffensen(Func<double, double> func, double p0, double TOL, int N0, out double p)
        {

            StreamWriter sw = new StreamWriter(Environment.CurrentDirectory + @"\testout.txt");
            int i = 1;
            double p1, p2;

            while (i <= N0)
            {
                p1 = func(p0);
                p2 = func(p1);

                // 判断迭代是否出现NaN
                if (double.IsNaN(Math.Pow(p1 - p0, 2) / (p2 - 2 * p1 + p0)))
                {
                    if (i == 1)
                    {
                        sw.WriteLine("第一次迭代就出现NaN，无法继续迭代！");
                        p = p0;
                        sw.Close();
                        return false;
                    }
                    else
                    {
                        sw.WriteLine("第{0}次迭代出现NaN，返回上一次迭代结果：{1}", i, p0);
                        p = p0;
                        sw.Close();
                        return true;
                    }
                }

                // 迭代公式
                p = p0 - Math.Pow(p1 - p0, 2) / (p2 - 2 * p1 + p0);
                Console.WriteLine("第{0}次迭代的解为：{1}", i, p);

                // 判断迭代是否收敛
                if (Math.Abs(p - p0) < TOL)
                {
                    sw.WriteLine("|p - p0| < TOL，迭代成功，解为：{0}", p);
                    sw.Close();
                    return true; // 迭代成功，返回true
                }

                p0 = p; // 更新近似解
                i++;
            }

            p = 0;

            sw.Close();
            return false;
        }

        // Secant法
        static bool Secant(Func<double, double> f, double p0, double p1, double TOL, int N0, out double p)
        {

            StreamWriter sw = new StreamWriter(Environment.CurrentDirectory + @"\testout.txt");

            int i = 2;
            double q0 = f(p0);
            double q1 = f(p1);

            while (i <= N0)
            {
                // 判断迭代是否出现NaN
                if (double.IsNaN(q1 * (p1 - p0) / (q1 - q0)))
                {
                    if (i == 1)
                    {
                        sw.WriteLine("第一次迭代就出现NaN，无法继续迭代！");
                        p = p1;
                        sw.Close();
                        return false;
                    }
                    else
                    {
                        sw.WriteLine("第{0}次迭代出现NaN，返回上一次迭代结果：{1}", i, p0);
                        p = p1;
                        sw.Close();
                        return true;
                    }
                }

                p = p1 - q1 * (p1 - p0) / (q1 - q0); // 迭代公式
                sw.WriteLine("第{0}次迭代的解为：{1}", i, p);

                // 判断迭代是否收敛
                if (Math.Abs(p - p1) < TOL)
                {
                    sw.WriteLine("|p - p1| < TOL，迭代成功，解为：{0}", p);
                    sw.Close();
                    return true; // 迭代成功，返回true
                }

                p0 = p1;
                q0 = q1;
                p1 = p;
                q1 = f(p);
                i++;
            }

            p = 0;
            sw.Close();
            return false; // 迭代失败，返回false
        }

        // 定义Romberg算法函数
        static double[,] RombergIntegration(Func<double, double> f, double a, double b, int n)
        {
            try
            {
                //Pass the filepath and filename to the StreamWriter Constructor
                StreamWriter sw = new StreamWriter(Environment.CurrentDirectory + @"\testout.txt");

                double h = b - a;
                double[,] R = new double[2, n + 1];

                R[0, 0] = h * (f(a) + f(b)) / 2;

                sw.WriteLine("R_1:\n{0}", R[0, 0]);
                sw.WriteLine();

                for (int i = 2; i <= n; i++)
                {
                    double sum = 0;
                    for (int k = 1; k <= Math.Pow(2, i - 2); k++)
                    {
                        double x = a + (2 * k - 1) * h / 2;
                        sum += f(x);
                    }

                    R[1, 0] = 0.5 * (R[0, 0] + h * sum);

                    for (int j = 2; j <= i; j++)
                    {
                        R[1, j - 1] = R[1, j - 2] + (R[1, j - 2] - R[0, j - 2]) / (Math.Pow(4, j - 1) - 1);
                    }

                    sw.WriteLine("R_{0}:", i);
                    for (int j = 0; j <= i - 1; j++)
                    {
                        sw.WriteLine("{0}\t", R[1, j]);
                    }
                    sw.WriteLine();

                    h /= 2;

                    for (int j = 0; j <= i - 1; j++)
                    {
                        R[0, j] = R[1, j];
                    }
                }
                sw.Close();
                return R;
            }
            catch
            {
                double[,] R = new double[1, 1] { { -1 } };
                return R;
            }
        }

        // 定义Euler方法函数
        static double[] Euler(double a, double b, int N, double alpha, Func<double, double, double> f)
        {
            double h = (b - a) / N; // 步长h
            double t = a;
            double w = alpha;

            double[] result = new double[N + 1];
            result[0] = alpha;

            for (int i = 1; i <= N; i++)
            {
                w = w + h * f(t, w); // 更新w
                t = a + i * h; // 更新t
                result[i] = w;
            }

            return result;
        }

        // 定义改进Euler方法函数
        static double[] ModifiedEuler(double a, double b, int N, double alpha, Func<double, double, double> f)
        {
            double h = (b - a) / N; // 步长h
            double t = a;
            double w = alpha;

            double[] result = new double[N + 1];
            result[0] = alpha;

            for (int i = 1; i <= N; i++)
            {
                w = w + (h / 2) * (f(t, w) + f(t + h, w + h * f(t, w))); // 更新w
                t = a + i * h; // 更新t
                result[i] = w;
            }

            return result;
        }

        // 定义Runge-Kutta方法函数
        static double[] RungeKutta(double a, double b, int N, double alpha, Func<double, double, double> f)
        {
            double[] w = new double[N + 1]; // 初始化w数组
            double h = (b - a) / N;
            double t = a;
            w[0] = alpha; // 初值条件

            for (int i = 1; i <= N; i++)
            {
                double K1 = h * f(t, w[i - 1]);
                double K2 = h * f(t + h / 2, w[i - 1] + K1 / 2);
                double K3 = h * f(t + h / 2, w[i - 1] + K2 / 2);
                double K4 = h * f(t + h, w[i - 1] + K3);
                w[i] = w[i - 1] + (K1 + 2 * K2 + 2 * K3 + K4) / 6; // 计算w值
                t = a + i * h; // 更新t
            }

            return w;
        }

        static double f(double t, double y)
        {
            return -y + t + 1;
        }
    }
}
