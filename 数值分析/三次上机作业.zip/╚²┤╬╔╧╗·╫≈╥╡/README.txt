尊敬的助教老师：
您好！
三次上机报告和对应的源文件分别在“第一次上机作业”、“第二次上机作业”、“第三次上机作业”三个文件夹中。我的程序
采用了C#语言编写，如果您想直接检查我的运行结果，可以在“\NumericalAnalysis\NumericalAnalysis\bin\Debug”中打开
“NumericalAnalysis.exe”这个程序查看。如果您想检查我的第一次程序代码，在文件夹“\第一次上机作业\程序\Numerical 
Analysis 1st test”中打开“Numerical Analysis 1st test.sln”查看即可。第二次、第三次的路径与第一次相仿。
此致
敬礼！

2023年4月16日