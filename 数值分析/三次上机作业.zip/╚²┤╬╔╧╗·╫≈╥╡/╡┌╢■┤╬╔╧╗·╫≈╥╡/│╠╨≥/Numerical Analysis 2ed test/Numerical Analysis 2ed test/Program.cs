﻿using System;

namespace Numerical_Analysis_2ed_test
{
    class Program
    {
        static void Main(string[] args)
        {
            // Question 1
            Func<double, double> f = x => Math.Pow(Math.E, 3 * x) - 5;
            Func<double, double> Func = x => x - Math.Pow(Math.E, 3 * x) + 5;
            Func<double, double> DFunc = x => 1 - 3 * Math.Pow(Math.E, 3 * x);
            double p0 = 0.5726219;
            double p1 = -1.5;
            double TOL = 1e-6;
            int N0 = 100;

            // 调用不动点迭代函数
            double q0 = FixedPointIteration(f, p0, TOL, N0);
            if (double.IsNaN(q0))
            {
                Console.WriteLine("不动点法迭代失败！");
            }
            else
            {
                Console.WriteLine("不动点法迭代正根：p = " + q0);
            }
            Console.WriteLine();
            // 负根
            double q1 = FixedPointIteration(f, p1, TOL, N0);
            if (double.IsNaN(q1))
            {
                Console.WriteLine("不动点法迭代失败！");
            }
            else
            {
                Console.WriteLine("不动点法迭代负根：p = " + q1);
            }
            Console.WriteLine();

            double p;
            // 调用Newton迭代法函数求解
            if (Newton(Func, DFunc, p0, TOL, N0, out p))
            {
                Console.WriteLine("Newton法迭代成功，正根为：{0}", p);
            }
            else
            {
                Console.WriteLine("Newton法迭代失败！");
            }
            Console.WriteLine();
            // 负根
            if (Newton(Func, DFunc, p1, TOL, N0, out p))
            {
                Console.WriteLine("Newton法迭代成功，负根为：{0}", p);
            }
            else
            {
                Console.WriteLine("Newton法迭代失败！");
            }
            Console.WriteLine();



            // Question 2
            Func<double, double> g = x => x - Math.Sin(x);
            Func<double, double> dg = x => 1 - Math.Cos(x);
            Func<double, double> ddg = x => Math.Sin(x);
            double x0 = 0.1;

            // 调用Newton法求解
            if (Newton(g, dg, x0, TOL, N0, out p))
            {
                Console.WriteLine("Newton法迭代成功，解为：{0}", p);
            }
            else
            {
                Console.WriteLine("Newton法迭代失败！");
            }
            Console.WriteLine();

            // 调用改进的Newton-Raphson方法求解
            if (ImprovedNewtonRaphson(g, dg, ddg, x0, TOL, N0, out p))
            {
                Console.WriteLine("Newton-Raphson方法迭代成功，解为：{0}", p);
            }
            else
            {
                Console.WriteLine("Newton-Raphson方法迭代失败！");
            }
            Console.WriteLine();

            // 调用Steffensen方法并输出结果
            if (Steffensen(g, x0, TOL, N0, out p))
            {
                Console.WriteLine("Steffensen方法迭代成功，解为：{0}", p);
            }
            else
            {
                Console.WriteLine("Steffensen方法迭代失败！");
            }
            Console.WriteLine();



            // Question 3
            Func<double, double> h = x => 600 * Math.Pow(x, 4) - 550 * Math.Pow(x, 3) + 200 * Math.Pow(x, 2) - 20 * x - 1;
            Func<double, double> dh = x => 2400 * Math.Pow(x, 3) - 1650 * Math.Pow(x, 2) + 400 * x - 20;
            double a = 0.1, b = 1, z0 = 0.1, z1 = 0.2;
            double eps = 1e-4;

            // 调用Bisection法并输出结果
            double z = Bisection(h, a, b, eps, N0);
            if (z == double.NaN)
            {
                Console.WriteLine("Bisection法迭代失败！");
            }
            else
            {
                Console.WriteLine($"Bisection法迭代成功，解为：{z}");
            }
            Console.WriteLine();

            // 调用Newton法并输出结果
            if (Newton(h, dh, z0, eps, N0, out p))
            {
                Console.WriteLine("Newton法迭代成功，解为：{0}", p);
            }
            else
            {
                Console.WriteLine("Newton法迭代失败！");
            }
            Console.WriteLine();

            // 调用Secant法并输出结果
            if (Secant(h, z0, z1, eps, N0, out p))
            {
                Console.WriteLine("Secant法迭代成功，解为：{0}", p);
            }
            else
            {
                Console.WriteLine("Secant法迭代失败！");
            }
            Console.WriteLine();
        }



        // Bisection法
        static double Bisection(Func<double, double> func, double a, double b, double TOL, int N0)
        {
            double p, f_a, f_b, f_p;
            int i;

            // 判断是否符合二分法的条件
            f_a = func(a);
            f_b = func(b);
            if (f_a * f_b >= 0)
            {
                Console.WriteLine("无法使用二分法求解！");
                return double.NaN;
            }

            // 开始二分法迭代
            for (i = 1; i <= N0; i++)
            {
                p = (a + b) / 2;
                f_p = func(p);
                if (Math.Abs(f_p) < TOL)
                {
                    Console.WriteLine($"迭代{i}次后，近似解为：{p}");
                    return p;
                }
                else if (f_a * f_p < 0)
                {
                    b = p;
                    f_b = f_p;
                }
                else
                {
                    a = p;
                    f_a = f_p;
                }
            }

            return double.NaN;
        }

        // 不动点迭代函数
        static double FixedPointIteration(Func<double, double> f, double p0, double TOL, int N0)
        {
            double p = p0;
            for (int i = 0; i < N0; i++)
            {
                double pPrev = p;
                p = f(p);
                if (Math.Abs(p - pPrev) < TOL)
                {
                    return p;
                }
            }
            return double.NaN;
        }

        // Newton迭代法函数
        static bool Newton(Func<double, double> f, Func<double, double> df, double p0, double TOL, int N0, out double p)
        {
            int i = 1;
            double fp0, dfp0;

            while (i <= N0)
            {
                fp0 = f(p0);     // 求函数值
                dfp0 = df(p0);   // 求导数值

                // 判断迭代是否出现NaN
                if (double.IsNaN(fp0 / dfp0))
                {
                    if (i == 1)
                    {
                        Console.WriteLine("第一次迭代就出现NaN，无法继续迭代！");
                        p = p0;
                        return false;
                    }
                    else
                    {
                        Console.WriteLine("第{0}次迭代出现NaN，返回上一次迭代结果：{1}", i, p0);
                        p = p0;
                        return true;
                    }
                }

                p = p0 - fp0 / dfp0; // 迭代公式
                Console.WriteLine("第{0}次迭代的解为：{1}", i, p);

                // 判断迭代是否收敛
                if (Math.Abs(p - p0) < TOL)
                {
                    Console.WriteLine("|p - p0| < TOL，迭代成功，解为：{0}", p);
                    return true; // 迭代成功，返回true
                }

                p0 = p; // 更新近似解
                i++;
            }

            p = 0;
            return false; // 迭代失败，返回false
        }

        // 改进的Newton-Raphson方法
        static bool ImprovedNewtonRaphson(Func<double, double> f, Func<double, double> df,  Func<double, double> ddf, double p0, double TOL, int N0, out double p)
        {
            int i = 1;
            double fp0, dfp0, ddfp0;

            while (i <= N0)
            {
                fp0 = f(p0);     // 求函数值
                dfp0 = df(p0);   // 求导数值
                ddfp0 = ddf(p0); // 求二阶导数值

                // 判断迭代是否出现NaN
                if (double.IsNaN((fp0 * dfp0) / (Math.Pow(dfp0, 2) - fp0 * ddfp0)))
                {
                    if (i == 1)
                    {
                        Console.WriteLine("第一次迭代就出现NaN，无法继续迭代！");
                        p = p0;
                        return false;
                    }
                    else
                    {
                        Console.WriteLine("第{0}次迭代出现NaN，返回上一次迭代结果：{1}", i, p0);
                        p = p0;
                        return true;
                    }
                }

                // 迭代公式
                p = p0 - (fp0 * dfp0) / (Math.Pow(dfp0, 2) - fp0 * ddfp0);
                Console.WriteLine("第{0}次迭代的解为：{1}", i, p);

                // 判断迭代是否收敛
                if (Math.Abs(p - p0) < TOL)
                {
                    Console.WriteLine("|p - p0| < TOL，迭代成功，解为：{0}", p);
                    return true; // 迭代成功，返回true
                }

                p0 = p; // 更新近似解
                i++;
            }

            p = 0;
            return false; // 迭代失败，返回false
        }

        // Steffensen方法
        static bool Steffensen(Func<double, double> func, double p0, double TOL, int N0, out double p)
        {
            int i = 1;
            double p1, p2;

            while (i <= N0)
            {
                p1 = func(p0);
                p2 = func(p1);

                // 判断迭代是否出现NaN
                if (double.IsNaN(Math.Pow(p1 - p0, 2) / (p2 - 2 * p1 + p0)))
                {
                    if (i == 1)
                    {
                        Console.WriteLine("第一次迭代就出现NaN，无法继续迭代！");
                        p = p0;
                        return false;
                    }
                    else
                    {
                        Console.WriteLine("第{0}次迭代出现NaN，返回上一次迭代结果：{1}", i, p0);
                        p = p0;
                        return true;
                    }
                }

                // 迭代公式
                p = p0 - Math.Pow(p1 - p0, 2) / (p2 - 2 * p1 + p0);
                Console.WriteLine("第{0}次迭代的解为：{1}", i, p);

                // 判断迭代是否收敛
                if (Math.Abs(p - p0) < TOL)
                {
                    Console.WriteLine("|p - p0| < TOL，迭代成功，解为：{0}", p);
                    return true; // 迭代成功，返回true
                }

                p0 = p; // 更新近似解
                i++;
            }

            p = 0;
            return false; // 迭代失败，返回false
        }

        // Secant法
        static bool Secant(Func<double, double> f, double p0, double p1, double TOL, int N0, out double p)
        {
            int i = 2;
            double q0 = f(p0);
            double q1 = f(p1);

            while (i <= N0)
            {
                // 判断迭代是否出现NaN
                if (double.IsNaN(q1 * (p1 - p0) / (q1 - q0)))
                {
                    if (i == 1)
                    {
                        Console.WriteLine("第一次迭代就出现NaN，无法继续迭代！");
                        p = p1;
                        return false;
                    }
                    else
                    {
                        Console.WriteLine("第{0}次迭代出现NaN，返回上一次迭代结果：{1}", i, p0);
                        p = p1;
                        return true;
                    }
                }

                p = p1 - q1 * (p1 - p0) / (q1 - q0); // 迭代公式
                Console.WriteLine("第{0}次迭代的解为：{1}", i, p);

                // 判断迭代是否收敛
                if (Math.Abs(p - p1) < TOL)
                {
                    Console.WriteLine("|p - p1| < TOL，迭代成功，解为：{0}", p);
                    return true; // 迭代成功，返回true
                }

                p0 = p1;
                q0 = q1;
                p1 = p;
                q1 = f(p);
                i++;
            }

            p = 0;
            return false; // 迭代失败，返回false
        }
    }
}
