﻿using System;

namespace Numerical_Analysis_1st_test
{
    class Program
    {
        static void Main(string[] args)
        {
            double[,] matrix = new double[,] {
                                              { 1.19,   2.11,  -100,  1 },
                                              { 14.2, -0.122,  12.2, -1 },
                                              {    0,    100, -99.9,  1 },
                                              { 15.3,  0.110, -13.1, -1 }
                                             };
            double[] rightSide = new double[] { 1.12, 3.44, 2.15, 4.16 };

            /// 3*) Gaussian elimination with scaled partial pivoting.
            double[] x3 = GaussianElimination(matrix, rightSide);            
            Console.WriteLine("6.2 Solution3:");
            for (int i = 0; i < x3.Length; i++)
            {
                Console.WriteLine("x{0} = {1}", i + 1, x3[i]);
            }
            Console.WriteLine();

            /// 2) Gaussian elimination with partial pivoting.
            try
            {
                double[] x2 = Solve(matrix, rightSide);

                Console.WriteLine("6.2 Solution2:");
                for (int i = 0; i < x2.Length; i++)
                {
                    Console.WriteLine("x[{0}] = {1}", i, x2[i]);
                }
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine("Error：{0}", ex.Message);
            }
            Console.WriteLine();

            /// 1) Gaussian elimination.
            double[] x1 = Gauss(matrix, rightSide);
            Console.WriteLine("6.2 Solution1:");
            for (int i = 0; i < x1.Length; i++)
            {
                Console.WriteLine("x{0} = {1}", i + 1, x1[i]);
            }
            Console.WriteLine();

            // Doolittle factorization
            double[,] A = { { 2, -1, 0, 0, 0, 0, 0, 0, 0, 0 }, 
                            { -1, 2, -1, 0, 0, 0, 0, 0, 0, 0 }, 
                            { 0, -1, 2, -1, 0, 0, 0, 0, 0, 0 },
                            { 0, 0, -1, 2, -1, 0, 0, 0, 0, 0 },
                            { 0, 0, 0, -1, 2, -1, 0, 0, 0, 0 },
                            { 0, 0, 0, 0, -1, 2, -1, 0, 0, 0 },
                            { 0, 0, 0, 0, 0, -1, 2, -1, 0, 0 },
                            { 0, 0, 0, 0, 0, 0, -1, 2, -1, 0 },
                            { 0, 0, 0, 0, 0, 0, 0, -1, 2, -1 },
                            { 0, 0, 0, 0, 0, 0, 0, 0, -1, 2 } };
            double[] b = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
            (double[,] L, double[,] U, double[] x) = CroutDecomposition(A, b);
            Console.WriteLine("6.6 Solution:");
            for (int i = 0; i < x.Length; i++)
            {
                Console.WriteLine("x{0} = {1}", i + 1, x[i]);
            }
            Console.WriteLine();

            // 定义三对角线性方程组的系数矩阵 A 和右侧向量 b
            double[,] teraMethodA = new double[40, 40];
            double[] teraMethodb = new double[40];
            for (int i = 1; i <= 40; i++)
            {
                for (int j = 1; j <= 40; j++)
                {
                    if (i == j)
                        teraMethodA[i - 1, j - 1] = 2 * i;
                    else if (j == i + 1 & (1 <= i & i <= 39))
                        teraMethodA[i - 1, j - 1] = -1;
                    else if (j == i - 1 & (2 <= i & i <= 40))
                        teraMethodA[i - 1, j - 1] = -1;
                    else
                        teraMethodA[i - 1, j - 1] = 0;
                }
            }
            for (int i = 1; i <= 40; i++)
                teraMethodb[i - 1] = 1.5 * i - 6;
            // 定义迭代法的初始近似值 x0 和误差容限 eps
            double[] x0 = new double[40];
            double eps = 1e-5;
            // 迭代次数上限
            int maxIterations = 100;
            // 定义松弛因子
            double omega = 1.2;

            // 调用 Jacobi 方法求解三对角线性方程组
            double[] Jacobix = Jacobi(teraMethodA, teraMethodb, x0, eps);
            Console.WriteLine("Jacobi Solution:");
            for (int i = 0; i < Jacobix.Length; i++)
            {
                Console.WriteLine("x[{0}] = {1}", i, Jacobix[i]);
            }
            Console.WriteLine();

            // 调用 GaussSeidel 迭代函数求解
            double[] result = GaussSeidel(teraMethodA, teraMethodb, x0, maxIterations, eps);
            Console.WriteLine("GaussSeidel Solution:");
            for (int i = 0; i < result.Length; i++)
            {
                Console.WriteLine("x[{0}] = {1}", i, result[i]);
            }
            Console.WriteLine();

            // 调用 SOR 方法求解线性方程组
            double[] SORx = SOR(teraMethodA, teraMethodb, x0, omega, maxIterations, eps);
            Console.WriteLine("SOR Solution:");
            for (int i = 0; i < SORx.Length; i++)
            {
                Console.WriteLine("x[{0}] = {1}", i, SORx[i]);
            }
            Console.ReadKey();
        }

        /// 3*) Gaussian elimination with scaled partial pivoting.
        public static double[] GaussianElimination(double[,] A, double[] b)
        {
            int n = b.Length;

            // 初始化比例因子
            double[] s = new double[n];
            for (int i = 0; i < n; i++)
            {
                s[i] = Math.Abs(A[i, 0]);
                for (int j = 1; j < n; j++)
                {
                    if (Math.Abs(A[i, j]) > s[i])
                    {
                        s[i] = Math.Abs(A[i, j]);
                    }
                }
            }

            // 比例因子部分选主元
            for (int k = 0; k < n - 1; k++)
            {
                double maxRatio = 0;
                int maxIndex = k;
                for (int i = k; i < n; i++)
                {
                    double ratio = Math.Abs(A[i, k] / s[i]);
                    if (ratio > maxRatio)
                    {
                        maxRatio = ratio;
                        maxIndex = i;
                    }
                }
                if (maxRatio == 0)
                {
                    throw new Exception("Singular matrix");
                }
                if (maxIndex != k)
                {
                    // 交换行
                    for (int j = k; j < n; j++)
                    {
                        double temp = A[k, j];
                        A[k, j] = A[maxIndex, j];
                        A[maxIndex, j] = temp;
                    }
                    double temp2 = b[k];
                    b[k] = b[maxIndex];
                    b[maxIndex] = temp2;
                    double temp3 = s[k];
                    s[k] = s[maxIndex];
                    s[maxIndex] = temp3;
                }

                // 消元
                for (int i = k + 1; i < n; i++)
                {
                    double factor = A[i, k] / A[k, k];
                    b[i] -= factor * b[k];
                    for (int j = k; j < n; j++)
                    {
                        A[i, j] -= factor * A[k, j];
                    }
                }
            }

            // 回代
            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0;
                for (int j = i + 1; j < n; j++)
                {
                    sum += A[i, j] * x[j];
                }
                x[i] = (b[i] - sum) / A[i, i];
            }
            return x;
        }

        /// 2) Gaussian elimination with partial pivoting.
        public static double[] Solve(double[,] A, double[] b)
        {
            int n = A.GetLength(0);

            for (int k = 0; k < n; k++) // k表示当前列
            {
                int pivotRow = k; // pivotRow表示绝对值最大的元素所在的行

                // 找到绝对值最大的元素所在的行
                for (int i = k + 1; i < n; i++)
                {
                    if (Math.Abs(A[i, k]) > Math.Abs(A[pivotRow, k]))
                    {
                        pivotRow = i;
                    }
                }

                // 将绝对值最大的元素所在的行与当前行进行交换（部分选主元）
                if (pivotRow != k)
                {
                    for (int j = k; j < n; j++)
                    {
                        double temp = A[k, j];
                        A[k, j] = A[pivotRow, j];
                        A[pivotRow, j] = temp;
                    }

                    double tempB = b[k];
                    b[k] = b[pivotRow];
                    b[pivotRow] = tempB;
                }

                // 检查矩阵是否奇异
                if (A[k, k] == 0)
                {
                    throw new ArgumentException("Matrix is singular.");
                }

                // 进行消元
                for (int i = k + 1; i < n; i++)
                {
                    double factor = A[i, k] / A[k, k];
                    for (int j = k + 1; j < n; j++)
                    {
                        A[i, j] -= factor * A[k, j];
                    }
                    b[i] -= factor * b[k];
                    A[i, k] = 0; // 将主元下方的元素置为0
                }
            }

            // 回代求解
            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0;
                for (int j = i + 1; j < n; j++)
                {
                    sum += A[i, j] * x[j];
                }
                x[i] = (b[i] - sum) / A[i, i];
            }

            return x;
        }

        /// 1) Gaussian elimination.
        public static double[] Gauss(double[,] A, double[] b)
        {
            int n = b.Length;

            // 前向消元
            for (int k = 0; k < n - 1; k++)
            {
                // 消元
                for (int i = k + 1; i < n; i++)
                {
                    double factor = A[i, k] / A[k, k];
                    for (int j = k + 1; j < n; j++)
                    {
                        A[i, j] -= factor * A[k, j];
                    }
                    b[i] -= factor * b[k];
                }
            }

            // 回带求解
            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0.0;
                for (int j = i + 1; j < n; j++)
                {
                    sum += A[i, j] * x[j];
                }
                x[i] = (b[i] - sum) / A[i, i];
            }

            return x;
        }

        // Doolittle factorization
        public static (double[,] L, double[,] U, double[] x) CroutDecomposition(double[,] matrix, double[] b)
        {
            int n = b.Length;
            double[,] L = new double[n, n];
            double[,] U = new double[n, n];
            double[] x = new double[n];

            // 执行 Crout 分解
            L[0, 0] = matrix[0, 0];
            U[0, 0] = 1.0;
            for (int i = 1; i < n; i++)
            {
                L[i, i - 1] = matrix[i, i - 1] / U[i - 1, i - 1];
                U[i - 1, i] = matrix[i - 1, i] / L[i - 1, i - 1];
                L[i, i] = matrix[i, i] - L[i, i - 1] * U[i - 1, i];
                U[i, i] = 1.0;
            }

            // 使用正向替换求解 Ly = b
            double[] y = new double[n];
            y[0] = b[0] / L[0, 0];
            for (int i = 1; i < n; i++)
            {
                double sum = 0.0;
                for (int j = 0; j < i; j++)
                {
                    sum += L[i, j] * y[j];
                }
                y[i] = (b[i] - sum) / L[i, i];
            }

            // 使用反向替换求解 Ux = y
            x[n - 1] = y[n - 1];
            for (int i = n - 2; i >= 0; i--)
            {
                double sum = 0.0;
                for (int j = i + 1; j < n; j++)
                {
                    sum += U[i, j] * x[j];
                }
                x[i] = y[i] - sum;
            }

            return (L, U, x);
        }

        // Jacobi
        static double[] Jacobi(double[,] A, double[] b, double[] x0, double eps)
        {
            int n = b.Length;
            double[] x = new double[n];     // 存放每次迭代后的解向量
            double[] x_new = new double[n]; // 存放每次迭代计算出的新解向量
            double err = 1;                 // 存放每次迭代后的误差

            // Jacobi 迭代法的迭代过程
            int k = 0;
            while (err > eps)
            {
                // 根据 Jacobi 迭代公式计算新的解向量
                for (int i = 0; i < n; i++)
                {
                    double sum = 0;
                    for (int j = 0; j < n; j++)
                    {
                        if (j != i)
                        {
                            sum += A[i, j] * x0[j];
                        }
                    }
                    x_new[i] = (b[i] - sum) / A[i, i];
                }

                // 计算新解向量与旧解向量之间的误差
                err = 0;
                for (int i = 0; i < n; i++)
                {
                    err += Math.Abs(x_new[i] - x0[i]);
                }

                // 将新解向量复制到解向量中，准备下一次迭代
                for (int i = 0; i < n; i++)
                {
                    x0[i] = x_new[i];
                }

                // 计算迭代次数
                k++;
            }

            Console.WriteLine("Number of iterations: {0}", k);

            return x_new;
        }

        // GaussSeidel
        static double[] GaussSeidel(double[,] A, double[] b, double[] x, int maxIterations, double tolerance)
        {
            int n = x.Length;
            int iterationCount = 0;
            double[] prevX = new double[n];

            while (iterationCount < maxIterations)
            {
                iterationCount++;

                // 保存上一次迭代的解向量
                for (int i = 0; i < n; i++)
                {
                    prevX[i] = x[i];
                }

                // 进行一次迭代
                for (int i = 0; i < n; i++)
                {
                    double sum = 0;

                    for (int j = 0; j < n; j++)
                    {
                        if (i != j)
                        {
                            sum += A[i, j] * x[j];
                        }
                    }

                    x[i] = (b[i] - sum) / A[i, i];
                }

                // 检查误差是否小于容限
                double error = 0;

                for (int i = 0; i < n; i++)
                {
                    error += Math.Abs(x[i] - prevX[i]);
                }

                if (error < tolerance)
                {
                    break;
                }
            }

            return x;
        }

        // SOR方法求解线性方程组 Ax = b
        // A: 系数矩阵，b: 常数矩阵，x0: 初始解向量，omega: 松弛因子，N: 迭代次数，TOL: 精度要求
        static double[] SOR(double[,] A, double[] b, double[] x0, double omega, int N, double TOL)
        {
            int n = b.Length; // 矩阵的大小

            // 定义迭代变量和误差数组
            int k = 0;
            double[] e = new double[n];

            // 定义解向量和中间变量数组
            double[] x = new double[n];
            double[] y = new double[n];

            // 初始化解向量
            for (int i = 0; i < n; i++)
            {
                x[i] = x0[i];
            }

            // 迭代求解
            while (k < N)
            {
                // 更新解向量
                for (int i = 0; i < n; i++)
                {
                    y[i] = x[i]; // 记录上一次的解向量
                    x[i] = (1 - omega) * x[i]; // 先乘以 (1 - omega)
                    double sum1 = 0;
                    double sum2 = 0;

                    // 求解 Ax = b 中的 sum1 和 sum2
                    for (int j = 0; j < i; j++)
                    {
                        sum1 += A[i, j] * x[j];
                    }
                    for (int j = i + 1; j < n; j++)
                    {
                        sum2 += A[i, j] * y[j];
                    }

                    // 更新解向量中第 i 个分量的值
                    x[i] = (1 - omega) * y[i] + omega * (b[i] - sum1 - sum2) / A[i, i];
                }

                // 计算当前解向量与上一次解向量的差的范数
                e[k] = Norm(x, y);

                // 如果误差小于精度要求，则跳出循环
                if (e[k] < TOL)
                {
                    break;
                }

                k++;
            }

            return x;
        }

        // 计算向量的范数
        // x: 向量，y: 向量
        static double Norm(double[] x, double[] y)
        {
            int n = x.Length; // 向量的大小
            double sum = 0;

            // 计算向量的平方差之和
            for (int i = 0; i < n; i++)
            {
                sum += Math.Pow(x[i] - y[i], 2);
            }

            // 返回向量的平方差之和的平方根
            return Math.Sqrt(sum);
        }
    }
}
