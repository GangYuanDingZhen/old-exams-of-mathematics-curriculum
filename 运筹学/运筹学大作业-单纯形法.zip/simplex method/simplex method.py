import re
import time
import numpy as np


def printer(text, delay=0.2):
    """打字机效果"""

    for ch in text:
        print(ch, end='', flush=True)
        time.sleep(delay)


def simplex(vector_c, matrix_A, vector_b):
    m, n = matrix_A.shape
    basis = np.arange(n - m, n)  # 初始基

    while True:
        Ab = matrix_A[:, basis]  # 从约束矩阵A中选择基础变量对应的列形成子矩阵Ab
        B_inv = np.linalg.inv(Ab)  # 计算Ab的逆矩阵，用于计算基础变量的取值xb
        vector_xb = np.dot(B_inv, vector_b)  # 计算基础变量的取值xb

        vector_cB = vector_c[basis]  # 从目标函数系数向量c中选择基础变量对应的系数形成向量cB
        vector_cb = np.dot(vector_cB, B_inv)  # 计算基础变量的对偶变量cb

        vector_y = np.dot(vector_cb, matrix_A) - vector_c  # 计算对偶变量乘以约束矩阵A后减去目标函数系数向量c，得到vector_y
        q = np.argmax(vector_y)  # 找到vector_y中最大值的索引，即选择使目标函数最大化的非基础变量q

        if vector_y[q] <= 0:
            vector_x = np.zeros(n)  # 初始化解向量x为全零向量
            vector_x[basis] = vector_xb  # 将基础变量的取值xb赋给解向量x的对应位置
            c_x = np.dot(vector_c, vector_x)  # 计算解向量x对应的目标函数值c_x
            return vector_x, c_x, basis  # 返回解向量x、目标函数值c_x和基础变量集合basis

        yB = np.dot(B_inv, matrix_A)  # 计算基础变量的对偶变量yB
        ratios = np.divide(vector_xb, yB[:, q], out=np.full_like(vector_xb, np.inf), where=yB[:, q] > 0)  # 计算基础变量对应的比率
        p = np.argmin(ratios)  # 找到比率中最小值的索引，即选择使基础变量退出基础集合的基础变量p

        if np.isinf(ratios[p]):
            raise Exception("The problem is unbounded.")  # 如果比率中的所有值都是无穷大，则问题无界

        basis[p] = q  # 将基础变量集合中第p个基础变量替换为非基础变量q


printer("欢迎使用单纯形法求解线性规划问题系统！\n")
printer("请输入您要求解的线性规划问题，我们提供了两种输入途径：\n")
printer("在控制台输入1，您将在控制台输入系数；（问题规模较小时，我们推荐这种方法）\n")
printer("在控制台输入2，您将在文本文档'simplex method.txt'中输入问题。（问题规模较大时，我们推荐这种方法）\n")
x = int(input("请选择您的输入方式："))

if x == 1:
    # 从控制台接收用户输入的参数
    num_variables = int(input("请输入变量的数量: "))
    num_constraints = int(input("请输入约束条件的数量: "))

    print("请输入目标函数的系数:")
    c = np.array([float(input(f"c[{i + 1}]: ")) for i in range(num_variables)])

    print("请输入约束矩阵:")
    A = np.array(
        [[float(input(f"A[{i + 1}][{j + 1}]]: ")) for j in range(num_variables)] for i in range(num_constraints)])

    print("请输入约束条件的右侧向量:")
    b = np.array([float(input(f"b[{i + 1}]: ")) for i in range(num_constraints)])

if x == 2:
    with open("simplex method.txt", mode='r', encoding='UTF-8') as f:
        ls = f.readlines()
        num_variables = int(re.search(r"\d+", ls[0]).group())
        num_constraints = int(re.search(r"\d+", ls[1]).group())

        str_c = re.split(r"x\d+", ls[3])
        c = np.array(list(map(int, str_c[:-1])))

        str_Ab = ls[5:]
        A = []; b = []
        for i in str_Ab:
            str_i = re.split(r"x\d+=*", i)
            A.append(list(map(int, str_i[:-1])))
            b.append(int(str_i[-1]))

        A = np.array(A)
        b = np.array(b)

# 调用单纯形法函数
try:
    x, cx, B = simplex(c, A, b)
    printer("\n最优解:")
    for i in range(num_variables):
        printer(f"\nx[{i + 1}] = {x[i]}")

    printer("\n最优值:")
    printer(f"\ncx = {cx}")

    printer("\n基础变量集合:")
    for i in range(num_constraints):
        printer(f"\nB[{i + 1}] = {B[i] + 1}")
except Exception as e:
    print("出现错误:", str(e))
